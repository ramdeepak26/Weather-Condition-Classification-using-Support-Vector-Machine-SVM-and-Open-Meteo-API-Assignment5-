"""
generate_demo_data.py
----------------------
This environment has no internet access, so the real Kaggle file
(WA_Fn-UseC_-HR-Employee-Attrition.csv) can't be downloaded here.

This script builds a synthetic dataset with the EXACT same 35 columns,
data types, and value ranges as the real IBM HR Analytics Attrition
dataset (1470 rows), with realistic correlations baked in (e.g. OverTime,
low JobSatisfaction, low MonthlyIncome, and high DistanceFromHome push
Attrition probability up). This lets Assignment-5.py be fully executed
end-to-end and produce genuine metrics/plots.

>>> To use the REAL data: download WA_Fn-UseC_-HR-Employee-Attrition.csv
>>> from the Kaggle link and drop it in this folder with that exact name.
>>> Assignment-5.py will automatically use it instead of the synthetic file.
"""

import numpy as np
import pandas as pd

np.random.seed(42)
n = 1470

department = np.random.choice(
    ["Sales", "Research & Development", "Human Resources"], n, p=[0.31, 0.65, 0.04]
)
job_role_map = {
    "Sales": ["Sales Executive", "Sales Representative", "Manager"],
    "Research & Development": [
        "Research Scientist", "Laboratory Technician", "Manufacturing Director",
        "Healthcare Representative", "Research Director", "Manager",
    ],
    "Human Resources": ["Human Resources", "Manager"],
}
job_role = np.array([np.random.choice(job_role_map[d]) for d in department])

education_field_map = {
    "Sales": ["Life Sciences", "Marketing", "Other"],
    "Research & Development": ["Life Sciences", "Medical", "Technical Degree", "Other"],
    "Human Resources": ["Human Resources", "Other"],
}
education_field = np.array([np.random.choice(education_field_map[d]) for d in department])

age = np.random.randint(18, 61, n)
business_travel = np.random.choice(
    ["Travel_Rarely", "Travel_Frequently", "Non-Travel"], n, p=[0.71, 0.19, 0.10]
)
daily_rate = np.random.randint(100, 1500, n)
distance_from_home = np.random.randint(1, 30, n)
education = np.random.randint(1, 6, n)
environment_satisfaction = np.random.randint(1, 5, n)
gender = np.random.choice(["Male", "Female"], n, p=[0.6, 0.4])
hourly_rate = np.random.randint(30, 101, n)
job_involvement = np.random.randint(1, 5, n)
job_level = np.random.randint(1, 6, n)
job_satisfaction = np.random.randint(1, 5, n)
marital_status = np.random.choice(["Single", "Married", "Divorced"], n, p=[0.32, 0.46, 0.22])
monthly_income = np.random.randint(1000, 20000, n)
monthly_rate = np.random.randint(2000, 27000, n)
num_companies_worked = np.random.randint(0, 10, n)
over_time = np.random.choice(["Yes", "No"], n, p=[0.28, 0.72])
percent_salary_hike = np.random.randint(11, 26, n)
performance_rating = np.random.choice([3, 4], n, p=[0.85, 0.15])
relationship_satisfaction = np.random.randint(1, 5, n)
stock_option_level = np.random.randint(0, 4, n)
total_working_years = np.clip(age - np.random.randint(18, 25, n), 0, None)
training_times_last_year = np.random.randint(0, 7, n)
work_life_balance = np.random.randint(1, 5, n)
years_at_company = np.clip(
    (total_working_years * np.random.uniform(0.2, 1.0, n)).astype(int), 0, None
)
years_in_current_role = np.clip(
    (years_at_company * np.random.uniform(0.2, 0.9, n)).astype(int), 0, None
)
years_since_last_promotion = np.clip(
    (years_at_company * np.random.uniform(0.0, 0.6, n)).astype(int), 0, None
)
years_with_curr_manager = np.clip(
    (years_at_company * np.random.uniform(0.2, 0.9, n)).astype(int), 0, None
)

# ---- Build attrition probability with realistic drivers, then sample ----
logit = (
    -2.2
    + 1.15 * (over_time == "Yes")
    + 0.55 * (job_satisfaction <= 2)
    + 0.45 * (environment_satisfaction <= 2)
    + 0.50 * (work_life_balance <= 2)
    + 0.60 * (marital_status == "Single")
    + 0.35 * (business_travel == "Travel_Frequently")
    + 0.02 * (distance_from_home)
    - 0.00006 * (monthly_income)
    - 0.05 * (years_at_company)
    - 0.06 * (job_level)
    + 0.05 * (num_companies_worked)
    - 0.015 * (age - 30)
)
prob_attrition = 1 / (1 + np.exp(-logit))
attrition = np.where(np.random.rand(n) < prob_attrition, "Yes", "No")

df = pd.DataFrame({
    "Age": age,
    "Attrition": attrition,
    "BusinessTravel": business_travel,
    "DailyRate": daily_rate,
    "Department": department,
    "DistanceFromHome": distance_from_home,
    "Education": education,
    "EducationField": education_field,
    "EmployeeCount": 1,
    "EmployeeNumber": np.arange(1, n + 1),
    "EnvironmentSatisfaction": environment_satisfaction,
    "Gender": gender,
    "HourlyRate": hourly_rate,
    "JobInvolvement": job_involvement,
    "JobLevel": job_level,
    "JobRole": job_role,
    "JobSatisfaction": job_satisfaction,
    "MaritalStatus": marital_status,
    "MonthlyIncome": monthly_income,
    "MonthlyRate": monthly_rate,
    "NumCompaniesWorked": num_companies_worked,
    "Over18": "Y",
    "OverTime": over_time,
    "PercentSalaryHike": percent_salary_hike,
    "PerformanceRating": performance_rating,
    "RelationshipSatisfaction": relationship_satisfaction,
    "StandardHours": 80,
    "StockOptionLevel": stock_option_level,
    "TotalWorkingYears": total_working_years,
    "TrainingTimesLastYear": training_times_last_year,
    "WorkLifeBalance": work_life_balance,
    "YearsAtCompany": years_at_company,
    "YearsInCurrentRole": years_in_current_role,
    "YearsSinceLastPromotion": years_since_last_promotion,
    "YearsWithCurrManager": years_with_curr_manager,
})

df.to_csv("demo_HR_Employee_Attrition.csv", index=False)
print("Synthetic demo dataset written to demo_HR_Employee_Attrition.csv")
print(df["Attrition"].value_counts(normalize=True))
