"""
Assignment-5.py
================
Employee Attrition Prediction using Decision Tree and Random Forest
Classification

Dataset : IBM HR Analytics Employee Attrition & Performance
Kaggle  : https://www.kaggle.com/datasets/pavansubhasht/ibm-hr-analytics-attrition-dataset

NOTE ON DATA FILE
-----------------
This script looks for "WA_Fn-UseC_-HR-Employee-Attrition.csv" (the exact
file name Kaggle gives you) in the same folder. If that file is not
found, it falls back to "demo_HR_Employee_Attrition.csv", a synthetic
dataset built with the identical 35-column schema (see
generate_demo_data.py) so the pipeline can still be run and graded.

To reproduce this analysis on the REAL data:
1. Download WA_Fn-UseC_-HR-Employee-Attrition.csv from the Kaggle link.
2. Place it in the same folder as this script.
3. Run: python Assignment-5.py
"""

import os
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

RANDOM_STATE = 42
os.makedirs("outputs", exist_ok=True)

# =====================================================================
# TASK 1: DATA UNDERSTANDING
# =====================================================================
print("=" * 70)
print("TASK 1: DATA UNDERSTANDING")
print("=" * 70)

REAL_FILE = "WA_Fn-UseC_-HR-Employee-Attrition.csv"
DEMO_FILE = "demo_HR_Employee_Attrition.csv"
data_path = REAL_FILE if os.path.exists(REAL_FILE) else DEMO_FILE
print(f"\nLoading dataset from: {data_path}"
      f"{'  (REAL Kaggle file)' if data_path == REAL_FILE else '  (synthetic demo file - real file not found)'}")

df = pd.read_csv(data_path)

print("\n--- First 5 records ---")
print(df.head())

print(f"\nShape of dataset: {df.shape}")

target_variable = "Attrition"

# Columns that are IDs / constants are not predictive features but are
# still part of the raw schema; they are identified here and removed in Task 2.
non_feature_cols = ["EmployeeCount", "EmployeeNumber", "Over18", "StandardHours"]

categorical_features = [
    c for c in df.columns
    if (df[c].dtype == "object" or pd.api.types.is_string_dtype(df[c]))
    and c != target_variable
]
numerical_features = [
    c for c in df.columns
    if c not in categorical_features and c not in [target_variable] + non_feature_cols
]

print("\n--- Target variable ---")
print(f"Target: {target_variable}  (binary: Yes/No)")

print("\n--- Categorical features ---")
print(categorical_features)

print("\n--- Numerical features ---")
print(numerical_features)

print("\n--- Dataset info ---")
df.info()

print("\n--- Summary statistics (numerical) ---")
print(df.describe())

print("\n--- Summary statistics (categorical) ---")
print(df[categorical_features + [target_variable]].describe())

# =====================================================================
# TASK 2: DATA PREPROCESSING
# =====================================================================
print("\n" + "=" * 70)
print("TASK 2: DATA PREPROCESSING")
print("=" * 70)

print("\n--- Missing values per column ---")
missing = df.isnull().sum()
print(missing[missing > 0] if missing.sum() > 0 else "No missing values found.")

# Remove unnecessary columns: constant / identifier columns carry no
# predictive signal (EmployeeCount and StandardHours are constant,
# Over18 is constant, EmployeeNumber is a unique ID).
print(f"\nDropping non-informative columns: {non_feature_cols}")
df_clean = df.drop(columns=non_feature_cols)

# Encode target variable
le_target = LabelEncoder()
df_clean["Attrition"] = le_target.fit_transform(df_clean["Attrition"])  # No=0, Yes=1
print(f"\nTarget classes encoded as: {dict(zip(le_target.classes_, le_target.transform(le_target.classes_)))}")

# Encode remaining categorical (object) columns with Label Encoding
cat_cols_to_encode = [
    c for c in df_clean.columns
    if df_clean[c].dtype == "object" or pd.api.types.is_string_dtype(df_clean[c])
]
print(f"Encoding categorical columns: {cat_cols_to_encode}")

encoders = {}
for col in cat_cols_to_encode:
    le = LabelEncoder()
    df_clean[col] = le.fit_transform(df_clean[col])
    encoders[col] = le

print("\n--- Data after encoding (first 5 rows) ---")
print(df_clean.head())

X = df_clean.drop(columns=["Attrition"])
y = df_clean["Attrition"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=RANDOM_STATE, stratify=y
)
print(f"\nTraining set size: {X_train.shape[0]} rows ({X_train.shape[0]/len(df_clean):.0%})")
print(f"Testing set size : {X_test.shape[0]} rows ({X_test.shape[0]/len(df_clean):.0%})")

# =====================================================================
# TASK 3: MODEL DEVELOPMENT
# =====================================================================
print("\n" + "=" * 70)
print("TASK 3: MODEL DEVELOPMENT")
print("=" * 70)

# Model 1: Decision Tree
dt_model = DecisionTreeClassifier(random_state=RANDOM_STATE)
dt_model.fit(X_train, y_train)
y_pred_dt = dt_model.predict(X_test)
print("\nDecision Tree Classifier trained.")

# Model 2: Random Forest (100 estimators)
rf_model = RandomForestClassifier(n_estimators=100, random_state=RANDOM_STATE)
rf_model.fit(X_train, y_train)
y_pred_rf = rf_model.predict(X_test)
print("Random Forest Classifier (100 estimators) trained.")

# =====================================================================
# TASK 4: MODEL EVALUATION AND COMPARISON
# =====================================================================
print("\n" + "=" * 70)
print("TASK 4: MODEL EVALUATION AND COMPARISON")
print("=" * 70)


def evaluate(name, y_true, y_pred):
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred)
    rec = recall_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    print(f"\n--- {name} ---")
    print(f"Accuracy : {acc:.4f}")
    print(f"Precision: {prec:.4f}")
    print(f"Recall   : {rec:.4f}")
    print(f"F1-Score : {f1:.4f}")
    print(classification_report(y_true, y_pred, target_names=["No", "Yes"]))
    return {"Model": name, "Accuracy": acc, "Precision": prec, "Recall": rec, "F1-Score": f1}


dt_metrics = evaluate("Decision Tree", y_test, y_pred_dt)
rf_metrics = evaluate("Random Forest", y_test, y_pred_rf)

results_df = pd.DataFrame([dt_metrics, rf_metrics])
print("\n--- Model comparison table ---")
print(results_df.to_string(index=False))
results_df.to_csv("outputs/model_comparison.csv", index=False)

# Confusion matrices
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
for ax, (name, y_pred) in zip(axes, [("Decision Tree", y_pred_dt), ("Random Forest", y_pred_rf)]):
    cm = confusion_matrix(y_test, y_pred)
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                xticklabels=["No", "Yes"], yticklabels=["No", "Yes"])
    ax.set_title(f"Confusion Matrix - {name}")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
plt.tight_layout()
plt.savefig("outputs/confusion_matrices.png", dpi=150)
plt.close()
print("\nSaved: outputs/confusion_matrices.png")

# Feature importance (Random Forest)
importances = pd.Series(rf_model.feature_importances_, index=X.columns).sort_values(ascending=False)
top_n = 15
plt.figure(figsize=(8, 6))
sns.barplot(x=importances.head(top_n).values, y=importances.head(top_n).index, color="#4C72B0")
plt.title(f"Top {top_n} Feature Importances - Random Forest")
plt.xlabel("Importance")
plt.tight_layout()
plt.savefig("outputs/feature_importance_rf.png", dpi=150)
plt.close()
print("Saved: outputs/feature_importance_rf.png")

print("\n--- Top 10 most important features (Random Forest) ---")
print(importances.head(10))

# Accuracy/metric comparison bar chart
plt.figure(figsize=(7, 5))
results_melt = results_df.melt(id_vars="Model", var_name="Metric", value_name="Score")
sns.barplot(data=results_melt, x="Metric", y="Score", hue="Model")
plt.ylim(0, 1)
plt.title("Decision Tree vs Random Forest - Metric Comparison")
plt.tight_layout()
plt.savefig("outputs/metric_comparison.png", dpi=150)
plt.close()
print("Saved: outputs/metric_comparison.png")

print("\n" + "=" * 70)
print("SCRIPT COMPLETE - see the outputs/ folder for saved charts and metrics")
print("=" * 70)
